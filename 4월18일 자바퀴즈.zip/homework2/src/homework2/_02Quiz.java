package homework2;
import java.util.Scanner;
public class _02Quiz {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int i = n;
		int sum = 0;
		while (i <= 100) {
			sum+=i;
			i++;
		}
		System.out.println(sum);
		
		
	}

}
