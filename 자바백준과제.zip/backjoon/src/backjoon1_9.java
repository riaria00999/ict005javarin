import java.util.Scanner;

public class backjoon1_9 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		// TODO Auto-generated method stub
//(A+B)%C는  와 같을까?
	 int A, B, C;
	 A = sc.nextInt();
	 B = sc.nextInt();
	 C = sc.nextInt();
	 
	 System.out.println((A+B)%C);
	 System.out.println(((A%C) + (B%C))%C);
	 System.out.println((A*B)%C);
	 System.out.println(((A%C) * (B%C))%C);
	 
	 
//(A×B)%C는 ((A%C) × (B%C))%C 와 같을까?
	}

}
