package homework2;
import java.util.Scanner;
public class _03Quiz {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int sum;
		for (int i = 1; i <= 10; i++) {
			sum = n * i;	
			System.out.println(sum);
		}
		
	}

}
