package homework2;
import java.util.Scanner;
public class _05Quiz {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int count = 0;
		int n = 1;
		
		while (n != 0) {
			n = sc.nextInt();
			if (n != 0 && n % 3 != 0 && n % 5 != 0) {
				count++;
			}
		}
		
		System.out.println(count);
	}
}