import java.util.Scanner;

public class backjoon1_7 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Id 입력: ");
		String Id = sc.nextLine();

		System.out.println(Id + "??" );
		
		// TODO Auto-generated method stub

	}

}
