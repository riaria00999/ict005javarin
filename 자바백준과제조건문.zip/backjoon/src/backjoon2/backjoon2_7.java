package backjoon2;
import java.util.Scanner;
public class backjoon2_7 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int A = sc.nextInt();
		int B = sc.nextInt();
		int C = sc.nextInt();
		int max;
		
		
		if (A == B && B == C) {
		    System.out.println(10000 + A * 1000);
		}
		else if (A == B || B == C || A == C) {
            int same;
            if (A == B) {
                same = A;
            }
            else if (B == C) {
                same = B;
            }
            else {
                same = A;
            }
            System.out.println(1000 + same * 100);
        }
		
		else if (A != B && A!=C&&C!=B) {
			max = Math.max(A, Math.max(B, C));
			System.out.println(max * 100);
		}

	}
}
