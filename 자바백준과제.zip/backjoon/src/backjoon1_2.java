import java.util.Scanner;

public class backjoon1_2 {

	public static void main(String[] args) {
		
	
		Scanner sc = new Scanner(System.in);
		
		int A,B;
		
		System.out.println("A 입력: ");
		A = sc.nextInt();
		
		System.out.println("B 입력: ");
		B = sc.nextInt();
		
		
		System.out.println(A+B);
	
	}

}
