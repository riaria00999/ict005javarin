
import java.util.Scanner;
public class backjoon1_8 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int x;
		
		x = sc.nextInt(); //불기년도
		int total = x - 543;	//서기년도
		
		System.out.println(total);
		
	
	}

}
