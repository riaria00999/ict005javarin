package homework2;
import java.util.Scanner;
public class _01Quiz {

	public static void main(String[] args) {
		
		Scanner ssc = new Scanner(System.in);
		int num = ssc.nextInt();
		int sum = 0;
		int i = 1;
		while (i <= num) {
			sum+=i;
			i++;					
		}
		
		System.out.println(sum);

		
	}

}
