package homework2;

public class _06Quiz {

    public static void main(String[] args) {
        for (int i = 2; i <= 6; i++) {
            for (int j = 0; j <= 4; j++) {
                System.out.print(i + j);
            }
            System.out.println();
        }
    }

}